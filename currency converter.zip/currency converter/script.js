async function convert() {
    const amount = document.getElementById('amount').value;
    const fromCurrency = document.getElementById('fromCurrency').value;
    const toCurrency = document.getElementById('toCurrency').value;
  
    const url = `https://api.exchangerate-api.com/v4/latest/${fromCurrency}`;
  
    try {
      const response = await fetch(url);
      const data = await response.json();
  
      if (data.error) {
        alert('Error fetching exchange rates.');
        return;
      }
  
      const exchangeRate = data.rates[toCurrency];
      const result = (amount * exchangeRate).toFixed(2);
  
      document.getElementById('result').value = `${result} ${toCurrency}`;
    } catch (error) {
      console.error('Error:', error);
      alert('An error occurred. Please try again later.');
    }
  }
  